# todo_app
ToDo App (Web App) made using Spring Initializr, MySQL and Eclipde IDE.
